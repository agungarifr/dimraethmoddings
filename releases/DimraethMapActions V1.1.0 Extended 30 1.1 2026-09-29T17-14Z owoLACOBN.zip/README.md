# DimraethMapActions v1.1.0 — Extended

Six map buttons: Train, Bounty Board, Respec, Befr Shop, Saqi Shop, Manga Forge.

Install `DimraethMapActions-v1.1.0-Extended.dll` in `Dimraeth/BepInEx/plugins` and restart the game. Remove `Dimraeth.MapQuickActions.dll`, `DimraethMapActionsExtended-v1.0.1.dll`, and any standard `DimraethMapActions-v1.1.0.dll`. Install one variant at a time.

The shop buttons use the real spawned NPC shops and their current stock. If the relevant NPC shop is not loaded, the button leaves the map open and shows a short unavailable message. Opening a menu does not buy, sell, craft, accept a bounty, confirm a respec, teleport, or write save files. Befr Shop and Manga Forge were confirmed in a character session. Saqi Shop opens when Saqi is visible; it is unavailable before her network shop spawns. Multiplayer remains untested.
