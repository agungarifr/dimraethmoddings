# DimraethMapActions v1.1.0

Three map buttons: Train, Bounty Board, Respec.

Install `DimraethMapActions-v1.1.0.dll` in `Dimraeth/BepInEx/plugins` and restart the game. Remove `Dimraeth.MapQuickActions.dll`, `DimraethMapActions-v1.1.0-Extended.dll`, and any older `DimraethMapActionsExtended` DLL. Install one variant at a time.

The buttons open the game's existing menus. Opening Respec starts a temporary refund UI session; Bounty Board makes the game's normal deed-data request. The mod does not buy, accept, confirm, teleport, or write save files. The three button paths were confirmed in game in the preceding build; this renamed build was compiled against the installed game.
