# Reno's Utilities

A circular minimap for Dimraeth with a player marker, compass, configurable position, and optional player head image.

## Requirements

- Dimraeth on Windows
- BepInEx 6 IL2CPP for Dimraeth
- The game must be started once with BepInEx so its interop assemblies are generated

## Installation

1. Install BepInEx 6 IL2CPP for Dimraeth.
2. Start the game once, then close it.
3. Copy `RenosUtilities.dll` into:

   `Dimraeth/BepInEx/plugins/`

4. Start the game.

BepInEx creates the configuration file here after the first launch:

`Dimraeth/BepInEx/config/RenosUtilitiesConfig.cfg`

## Configuration

The configuration file contains settings for:

- Map size, margin, and screen corner
- Zoom and camera height
- 2D or 3D map mode
- Player detection by object name or `Player` tag
- Compass visibility and rotation
- Configurable show/hide toggle hotkey (`F8` by default)
- Player marker size
- Player head image size and centering
- Optional head image path override

The default head image is located at:

`PlayerUIRoot/NPCDialogueUI/NPCTalk/PlayerIllustrations/PlayerInConvo/Head`

The minimap hides automatically while the NPC dialogue panel is open.

Press `F8` to show or hide the minimap. Change `ToggleKey` in the generated config file to use another key, or set it to `None` to disable the shortcut.

## Building From Source

The project targets `net6.0` and references the local BepInEx installation. Update the `GameDir` property in `DimraethMinimap.csproj` if the game is installed somewhere else, then build with:

```powershell
dotnet build -c Release
```

The compiled plugin is written to the project's `bin/Release/net6.0/` directory.

## Troubleshooting

- If the minimap does not appear, confirm that BepInEx loaded the plugin in `BepInEx/LogOutput.log`.
- If the player is not detected, set `PlayerObjectName` to the exact player GameObject name.
- If the map is too large or small, adjust `Size`, `Zoom`, and `MarkerSize` in the generated config file.
- Delete the generated `RenosUtilitiesConfig.cfg` only when you want BepInEx to recreate it with defaults.

Credits:
Reno
discord: mollerino
feel free to contact me for questions